<?php

$data = array(
    array(
        'company' => 'Alcoa Inc',
        'price' => 71.72,
        'change' => 0.02,
        'pctChange' => 0.03,
        'lastChange' => '9/1 12:00am'
    ),
    array(
        'company' => 'Altria Group Inc',
        'price' => 83.81,
        'change' => 0.28,
        'pctChange' => 0.34,
        'lastChange' => '9/1 12:00am'
    ),
    array(
        'company' => 'American International Group, Inc.',
        'price' => 81.82,
        'change' => 0.12,
        'pctChange' => 0.63,
        'lastChange' => '9/1 12:00am'
    ),
);

if(!headers_sent()){
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
}
